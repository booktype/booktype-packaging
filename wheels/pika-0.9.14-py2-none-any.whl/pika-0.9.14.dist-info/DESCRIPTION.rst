Pika is a pure-Python implementation of the AMQP 0-9-1 protocol that tries to stay fairly independent of the underlying network support  library. Pika was developed primarily for use with RabbitMQ, but should also work with other AMQP 0-9-1 brokers.


